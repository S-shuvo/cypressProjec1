///<reference types="cypress"/>
import dropdown from "../pages object model/drop_down.cy";
const drop_down = new dropdown();

describe('verify that dropdown page is working fine', ()=>{

it('verify that user is able to select from drop down', ()=>{

    cy.visit('https://the-internet.herokuapp.com/dropdown');
    drop_down.dropdown.should('exist');
    
});


it('verify that user is able to select from drop down', ()=>{

    cy.visit('https://the-internet.herokuapp.com/dropdown');
    drop_down.dropdown.should('exist');
    drop_down.dropdown.should(1);
    
});

});