///<reference types="cypress"/>
//it.skip() for skipping any test case
import filedownload from "../pages object model/file_download.cy";
const file_download = new filedownload();


describe('To verify the test cases of download page', () => {

    it('To verify user is able to click on download link', () => {

        cy.visit('https://the-internet.herokuapp.com/download');
        cy.wait(3000);
        file_download.seleniumsnapshot.click();

    });

    it('To verify the downloadable link should be present', () => {
        cy.visit('https://the-internet.herokuapp.com/download')
        file_download.example.should('exist');
    });

});