///<reference types = "cypress"/>

export default class filedownload{

    seleniumsnapshot(){

        let selenium_snapshot =  cy.get('[href="download/selenium-snapshot (2).png"]');

    }

    example(){
        
        let script = cy.get('[href="download/example.txt"]');
    }
}