///<reference types="cypress"/>

describe("To verify that login page is working fine",() =>{

it("verify that user is able to login by entering user and password", ()=>{

    cy.visit('https://the-internet.herokuapp.com/login')
    cy.get('#username').type('tomsmith');
    cy.get('#password').type('SuperSecretPassword!');
    cy.get('.radius').click();


});

});