///<reference types = "cypress"/>

describe('verify the file upload is working correctly', ()=> {

    it('verify', ()=>{

        cy.visit("https://the-internet.herokuapp.com/upload");
        cy.get('#file-upload').selectFile('Users/shofiqurrahman/Downloads/red-white-cat-i-white-studio.jpg');
        cy.get('#file-submit').click();





    });
});