///<reference types = "cypress"/>

export default class dropdown{

    dropdown(){

        let drop_down = cy.get('#dropdown');

    }
}