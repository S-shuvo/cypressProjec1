///<reference types = "cypress"/>

describe("verify that javascrip alert is working fine", () => {

    it("verify that user is able to handle alerts", ()=> {

        cy.visit('https://the-internet.herokuapp.com/javascript_alerts');
        cy.get(':nth-child(1) > button').click();

        //cy.on('windows:alert');
        

    });

    it("verify that user is click on to js confirm", ()=> {

        cy.visit('https://the-internet.herokuapp.com/javascript_alerts');
        cy.get(':nth-child(2) > button').click();

        cy.on('windows:confirm', (w)=>{
            expect(w).to.equal("I am a JS Confirm");
        });
        

    });
});